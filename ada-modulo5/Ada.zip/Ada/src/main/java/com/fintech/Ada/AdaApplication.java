package com.fintech.Ada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdaApplication.class, args);
	}

}
