package com.fintech.Ada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
